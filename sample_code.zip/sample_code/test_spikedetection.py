from NeoAnalysis import SpikeDetection

# you can load spike_detection_data.h5 for testing
SpikeDetection()